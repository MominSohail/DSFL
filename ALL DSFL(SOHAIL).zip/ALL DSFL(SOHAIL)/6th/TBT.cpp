#include <iostream>
#include <string.h>
#include "TBT.h"
#include "List.h"
using namespace std;


void TBT::createPreT(char TBTPre[])//to create Post Fix TBTression tree
{
	int l;
	 node *temp1=NULL,*temp2=NULL;
	l=strlen(TBTPre); //to find length
	l--;
	while(l>=0) //scan from right to left
	{
		 Root=new node;
		 Root->data=TBTPre[l];
		 if(isalnum(TBTPre[l]))  //if Operand
			  {
		           Root->Lchild=Root->Rchild=NULL;
		           Root->Lbit=Root->Rbit=1;
		           S.push(Root);
			  }
			  else  ///if operator  pop two operand and join to operand
			  {
				  Root->Lchild=S.pop();
				  Root->Rchild=S.pop();
				  Root->Lbit=Root->Rbit=0;//assigned link so Lbit & Rbit =0

				  //join left thread to parent
				  if(Root->Lchild->Rbit==1)
				  {
				  Root->Lchild->Rchild=Root;
				  }
				  //join Right thread to parent
				  if(Root->Rchild->Lbit==1)
				  {
				  Root->Rchild->Lchild=Root;
				  }
				   temp1=Root->Lchild;
				   temp2=Root->Rchild;

				   while(temp1->Rbit==0)
					  temp1=temp1->Rchild;
				   temp1->Rchild=Root;

				   while(temp2->Lbit==0)
					   temp2=temp2->Lchild;
				   temp2->Lchild=Root;
		          S.push(Root);
			  }
		l--;
	}
	Root=S.pop();

	  temp1=Root;
	  //joining Right most child to Head
	    while(temp1->Rchild->Rbit==0)
	    {
	    	temp1=temp1->Rchild;
	    }
	    if(temp1->Rchild->Rbit==1)
	    	temp1->Rchild->Rchild=headPre;

	    //Joining Left most child to head
	    temp2=Root;
	    while(temp2->Lchild->Lbit==0)
	       {
	       	temp2=temp2->Lchild;
	       }
	       if(temp2->Lchild->Lbit==1)
	       	temp2->Lchild->Lchild=headPre;

	       headPre->Lchild=Root; //connect complete Tree to Head
	       headPre->Rchild=headPre;
	  cout<<"\nTBT created for PreFix Expression whose Root is->"<<headPre->Lchild->data<<endl;
}

void TBT::createPostT(char TBTPost[])//function to create Postfix TBTression Tree
{

  int i=0;
   node *temp1=NULL,*temp2=NULL;
  while(TBTPost[i]!='\0')//scan from left to right
  {

	  Root=new node;
	  Root->data=TBTPost[i];

	  if(isalnum(TBTPost[i]))  //if Operand
	  {
           Root->Lchild=Root->Rchild=NULL;
           Root->Lbit=Root->Rbit=1;
           S.push(Root);
	  }
	  else  ///if operator  pop two operand and join to operand
	  {
		  Root->Rchild=S.pop();
		  Root->Lchild=S.pop();
		  Root->Lbit=Root->Rbit=0;//assigned link so Lbit & Rbit =0

		  //join left thread to parent
		  if(Root->Lchild->Rbit==1)
		  {
		  Root->Lchild->Rchild=Root;
		  }
		  //join Right thread to parent
		  if(Root->Rchild->Lbit==1)
		  {
		  Root->Rchild->Lchild=Root;
		  }
		   temp1=Root->Lchild;
		   temp2=Root->Rchild;

		   while(temp1->Rbit==0)
			  temp1=temp1->Rchild;
		   temp1->Rchild=Root;

		   while(temp2->Lbit==0)
			   temp2=temp2->Lchild;
		   temp2->Lchild=Root;
          S.push(Root);
	  }
	  i++;
  }
  Root=S.pop();
  temp1=Root;
  //joining Right most child to Head
    while(temp1->Rchild->Rbit==0)
    {
    	temp1=temp1->Rchild;
    }
    if(temp1->Rchild->Rbit==1)
    	temp1->Rchild->Rchild=headPost;

    //Joining Left most child to head
    temp2=Root;
    while(temp2->Lchild->Lbit==0)
       {
       	temp2=temp2->Lchild;
       }
       if(temp2->Lchild->Lbit==1)
       	temp2->Lchild->Lchild=headPost;

       headPost->Lchild=Root; //connect complete Tree to Head
       headPost->Rchild=headPost;
       //head->Lbit=head->Rbit=0;
  cout<<"\nTBT created for PostFix Expression whose Root is->"<<headPost->Lchild->data<<endl;
}




void TBT::TBT_Preorder(node *head)
{
	node *T;
	T=head->Lchild;
	if(T==head)
	{
		cout<<"Empty TBT...!";
		return ;
	}
	else
	{
		while(T!=head)
		{
			cout<<T->data;
			if(T->Lbit==0)
				T=T->Lchild;
			else
			{
				while(T->Rbit==1)
				{
					T=T->Rchild;
				}
				T=T->Rchild;
			}
		}
	}

}

void TBT::TBT_Inorder(node *head)
{

	node *t;
	t=head->Lchild;
	if(t==head)
	{
		cout<<"TBT is Empty....!";
		return ;
	}
	while(t->Lbit==0)
		t=t->Lchild;
	while(t!=head)
	{
		cout<<t->data;
		if(t->Rbit==1)
			t=t->Rchild;
		else
		{
			t=t->Rchild;
			while(t->Lbit==0)
				t=t->Lchild;
		}
	}
}
int main() {
	TBT E;
	char TBTPost[20];
	char TBTPre[20];
	int c=0;
	while(c<=5)
	{
		cout<<"\n\n1.Create PostFix Expression TBT\n2.Create PreFix Expression Tree";
        cout<<"\n3.PreOrder traversal of TBT \n4.Inorder Traversal of TBT \n5.Exit";
		cout<<"\nEnter Your Choice";
		cin>>c;
        switch(c)
        {
        case 1:
        	  cout<<"\nEnter PostFix Expression";
            	cin>>TBTPost;

    	        E.createPostT(TBTPost);
    	break;
        case 2:
        	cout<<"\nEnter PreFix Expression";
        	cin>>TBTPre;
        	  E.createPreT(TBTPre);
        	break;
        case 3:
        	cout<<"\nPreOrder Traversal of Postfix Expression TBT : ";
        	                    E.TBT_Preorder(E.headPost);
        	cout<<"\nPreOrder Traversal of Preorder Expression TBT : ";
                E.TBT_Preorder(E.headPre);

        	break;
        case 4:
        	cout<<"\nInorder Traversal of Postfix Expression TBT : ";
        	         E.TBT_Inorder(E.headPost);
        	 cout<<"\nInorder Traversal of Preorder Expression TBT : ";
        	                E.TBT_Inorder(E.headPre);

        	break;
        case 5:
        	return 0;
        			break;
        default:cout<<"\nIncorrect Choice";
        }
	}
	return 0;
}
