
#ifndef LIST_H_
#define LIST_H_
#include <iostream>
struct node
{
	char data;
	 node *Rchild;
	 node *Lchild;
	 bool Lbit=1;
	 bool Rbit=1;
};
class List
{
public :
	node *StackData[20];
	int top;
	List()
	{
		top=-1;
	}
	void insert(node *Tnode);
    node *del();
    bool isempty();
};
#endif /* LIST_H_ */
