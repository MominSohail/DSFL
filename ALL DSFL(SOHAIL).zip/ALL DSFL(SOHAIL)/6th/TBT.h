
#ifndef EXPTREE_H_
#define EXPTREE_H_
#include "Stack.h"
#include "List.h"
#include <iostream>
class TBT
{
public:
	Stack S;
	node *headPost,*headPre;

	node *Root;
	TBT()  //constructor
	{
		Root=NULL;

			headPost=new node; //create head node for Post Fix TBT
			headPost->data=0;
			headPost->Rchild=headPost->Lchild=headPost;
			headPost->Lbit=headPost->Rbit=0;

			headPre=new node;//create head node for Prefix TBT
			headPre->data=0;
			headPre->Rchild=headPre->Lchild=headPre;
			headPre->Lbit=headPre->Rbit=0;
	}
	//function prototype for creation of tree
	 void createHead();
	void createPostT(char expPost[]);
	void createPreT(char expPre[]);

	 void TBT_Preorder(node *head);
	 void TBT_Inorder(node *head);


};
#endif /* EXPTREE_H_ */
