//TITLE: Implement Heap Sort by constructing max or min heap.

#include<iostream>
#include<stdlib.h>

using namespace std;

#define MAX 10


class heap
{
      int heap[MAX],n;

      public:
             void accept();
             void display();
             void downadj(int i);
             void sort();
             void create_maxheap();
};


void heap::accept()
{
	cout<<"\nEnter No of elements: ";
	cin>>n;

	for(int i=1;i<=n;i++)
	{
		cout<<"\nEnter "<<i<<" Element: ";
		cin>>heap[i];
	}
	heap[0]=n;
}


void heap::display()
{

	for(int i=1;i<=n;i++)
	{
		cout<<" "<<heap[i];
	}
}

void heap::create_maxheap()
{
	int i;
	//heap[0]=n;
    	for(i=n/2;i>=1;i--)
      	{
        	downadj(i);
        	//heap[0]--;
      	}
      	display();
}


void heap::sort()
{
     int t,i,p;		//j
     heap[0]=n;
     for(i=n;i>1;i--)
       {
          t=heap[i];
          heap[i]=heap[1];
          heap[1]=t;
          heap[0]--;
          downadj(1);
          cout<<"\nAfter sort:\n ";
          cout<<"\n\nPASS"<<n-i+1;		//use j instead of n-i+1
          					//j++
          display();


       }
 }

void heap::downadj(int i)
{
     int temp,j;
     while(2*i<=heap[0])
     {
         j=2*i;
         if(j+1<=heap[0] && heap[j+1]>heap[j])
         {
           j++;
         }
         if(heap[j]>heap[i])
         {
         	temp=heap[i];
         	heap[i]=heap[j];
         	heap[j]=temp;
        	i=j;
      	 }
      	 else
         	break;
    }
}

int main()
{
	int ch;
	heap h;
	do
	{
		cout<<"\n\t*****HEAP SORT*****";
		cout<<"\n*********MENU*********";
		cout<<"\n1.Accept\n2.Sort\n3.Exit";
		cout<<"\nEnter your choice: ";
		cin>>ch;
		switch(ch)
		{
			case 1:
				h.accept();
				break;


			case 2:	h.create_maxheap();
				cout<<"\nHEAP:\n ";
				h.display();
				h.sort();

				break;
                   case 3:
				exit(0);
			}
	}while(ch!=4);
return 0;
}





























































