//============================================================================
    // Name        : Hashing.cpp
// Author      : SOHAIL
// Version     :
// Copyright   : Your copyright notice
// Description : Hello World in C++, Ansi-style
//============================================================================

#include "Hashing.h"
#include <iostream>
using namespace std;

void hashing::display_Hash()
{

	cout<<"\nIndex\tKey\tchain";
	for(i=0;i<max;i++)
	{
		if(flag[i]==1)
		cout<<"\n"<<i<<"\t"<<hash_Table[i]<<"\t"<<chain[i];
		else
			cout<<"\n"<<i<<"\t"<<"NULL"<<"\t"<<chain[i];
	}
}

void hashing ::insert_With_Rep(int key)
{
  int loc,j,t;
   i=0;
	loc=h(key);
	if(flag[loc]==0) //case 1
	{
		cout<<"\nNo Collision as No element at Location "<<loc;
		hash_Table[loc]=key;
		flag[loc]=1;
		cout<<"\nHence Given Element inserted at Location "<<loc;
	}
	else if(flag[loc]==1) //case 2
	{
		cout<<"\nAlready Present Element at this location Hence Collision Occur ";
				cout<<"Linear probing Apply ";
		t=h(hash_Table[loc]);

		if(loc==t)
		{
			j=loc;
				j=(j+1)%max;
				while(flag[j]==1 && j!=loc)
					j=(j+1)%max;
				if(j==loc)
				{
					cout<<"\nHash Table is Full...";
					return;
				}
				hash_Table[j]=key;
				cout<<"\nGiven Element Places At Location "<<j;
						flag[j]=1;
						if(chain[loc]==-1)
							{chain[loc]=j;
							cout<<" And Chain Updated at location "<<loc;
							}
						else
						{
						        i=chain[loc];
								  while(chain[i]!=-1) //find chain for update
									  i=chain[i];
						chain[i]=j;
						cout<<"And Chain Updated at location "<<i;
						}
		}
		else    //case 3
		{
			j=loc;
		j=(j+1)%max;
		while(flag[j]==1 && j!=loc)
			j=(j+1)%max;
		if(j==loc)
		{
			cout<<"\nHash Table is Full...";
			return;
		}
		hash_Table[j]=hash_Table[loc];
		chain[j]=chain[loc];
       cout<<"\nElement at "<<loc<<" has different hash Value so it is inserted at "<<j;
		  i=0;
		  while(chain[i]!=loc) //find chain for update
			  i=(i+1)%max;
		   if(chain[i]==loc)
			   {chain[i]=j;
			   cout<<" And whose Chain Updated At Location "<<i;
			   }

		   flag[j]=1;

				hash_Table[loc]=key;
				flag[loc]=1;
				chain[loc]=-1;
				cout<<"\nGiven Element Inserted At Location "<<loc;
		}
	}

}

void hashing ::insert_Without_Rep(int key)
{
  int loc,j,k;
   i=0;
	loc=h(key);
	cout<<"\nHash Value of given value is :"<<loc;
	if(flag[loc]==0)
	{
		cout<<"\nNo Collision as No element at Location "<<loc;
		hash_Table[loc]=key;
		flag[loc]=1;
		cout<<"\nHence Given Element inserted at Location "<<loc;
	}
	else
	{
		cout<<"\nAlready Present Element at this location Hence Collision Occur Linear probing Apply ";
		k=h(hash_Table[loc]);
		j=loc;
		j=(j+1)%max;
		while(flag[j]==1 && j!=loc)
			j=(j+1)%max;
		if(j==loc)
		{
			cout<<"\nHash Table is Full...";
			return;
		}
		hash_Table[j]=key;
		cout<<"\nGiven Element Places At Location "<<j;
		flag[j]=1;
		if(k==loc)
		{
			i=loc;
				  while(chain[i]!=-1) //find chain for update
					  i=chain[i];
			chain[i]=j;
			cout<<" And Chain Updated At Location "<<i;
		}
		else
			cout<<" No Chain Update as Hash value are Not Same";
	}

}


void hashing::search(int key)
{
	int loc,j;
	loc=h(key);
	if(hash_Table[loc]==key)
	{
		cout<<"\nGiven element found at "<<loc<<" location in Hash Table";
		return;
	}
	else
	{
		j=loc;
		while(chain[j]!=-1)
		{
			j=chain[j];
			if(hash_Table[j]==key)
				{
					cout<<"\nGiven element found at "<<j<<" location in Hash Table";
					return;
				}
		}
		cout<<"\n Given Element NOT Found ....";
	}
}

int main() {

	int c=0,d;
	int method=3;
	hashing H;
	while(method!=1 && method!=2)
	{
	cout<<"\n***Hash Table creation and handle collision using linear probing ***";
	cout<<"\n1.Chaining WITHOUT Replacement: ";
	cout<<"\n2.Chaining WITh Replacement: ";
	cout<<"\nEnter Your Choice :";
	cin>>method;
	if(method!=1 && method!=2)
		cout<<"\nIncorrect Choice.....";
	}
	while(c<4)
	{

		cout<<"\n\n\n1.Insert Integer Value in Hash Table \n2.Search for value \n3.Display Hash Table \n4.Exit";
		cout<<"\nEnter Your choice :";
		cin>>c;
		switch(c)
		{
		case 1:
			cout<<"\nBefore Insertion your Hash Table :";
			H.display_Hash();
			  cout<<"\nEnter Integer Value to be insert in Hash Table :";
			  cin>>d;
			  if(method==1)
			    H.insert_Without_Rep(d);  //call function without replacement
			  if(method==2)
				  H.insert_With_Rep(d);  //call function with replacement
			  cout<<"\nAfter Insertion your Hash Table :";
			  H.display_Hash();
			  break;
		case 2:
			cout<<"\nEnter Element to be search ";
			cin>>d;
			H.search(d);
			break;
		case 3:
			cout<<"\nYour Hash Table :";
			H.display_Hash();
			break;
		case 4:
			return 0;
			break;
		}
	}
}
