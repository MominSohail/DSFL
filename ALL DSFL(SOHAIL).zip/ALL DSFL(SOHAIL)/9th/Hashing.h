/*
 * Hashing.h
 *
 *  Created on: Mar 27, 2016
 *      Author: SOHAIL MOMIN
 */

#ifndef HASHING_H_
#define HASHING_H_

#include<iostream>
#define max 10
class hashing
{
public:
	int hash_Table[max],i,chain[max],flag[max];
	hashing()
	{
		for(i=0;i<max;i++)
		{
			chain[i]=-1;
			flag[i]=0;
			hash_Table[i]=00;
		}
	}

	int h(int key)              //hash Function
		{return key%max;}

	void insert_Without_Rep(int key);
    void insert_With_Rep(int key);
	void display_Hash();
	void search(int d);
};
#endif /* HASHING_H_ */
