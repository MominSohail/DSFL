/*
 * List.h
 *
 *  Created on: Dec 28, 2015
 *      Author: SOHAIL MOMIN
 */

#ifndef LIST_H_
#define LIST_H_
//Prototype declaration for Linked List Operation using template
template <class T>
struct node
{
	T data;
	 node *next=NULL;
};
template <class T>
class list
{

public:
	node<T> *head=NULL,*p;
		int n,i;
	bool listempty();
	void displayList();
    void insert(T d);
    T Delete();
    T topData();
};
#endif /* LIST_H_ */
