/*
 *  Stack.h
 *
 *  Created on: Dec 28, 2015
 *      Author: SOHAIL MOMIN
 */

#ifndef STACK_H_
#define STACK_H_
#include "List.h"
#include "List.cpp"
//Declaration for Stack Operation
template <class T>
class Stack
{

public:
   list <T> lc;  //object for character Stack


   // st is parameter variable which define which data type of stack is

    void push(T x);
	void display();
	bool isempty();
	T pop();
	T TopData();

};


#endif /* STACK_H_ */
