/*
 * conversion.h
 *
 *  Created on: 28-Dec-2015
 *      Author: pict
 */

#ifndef CONVERSION_H_
#define CONVERSION_H_
#include "Stack.h"
#include <string.h>
class Conversion
{

public:
	char infix[20];
				char postfix[20];
				char temp[20];
				char prefix[20];

	Stack <char> SOC;     //object for character Stack
	Stack <int>  SOI;     //object for Integer Stack

	void input();
	int isOperand(char in);
	int isOperator(char in);
	int precedence(char in);
	bool isRightAsso(char in);
	int pow(int op1,int op2);
	void convertInfixToPostfix();
	void convertInfixToPrefix();
    void evaluatePost();
    void evaluatePre();
	void display();
};



#endif /* CONVERSION_H_ */
