#include <iostream>
#include "List.h"
using namespace std;

//Definitions of Operation function on linked List
template <class T>
bool list<T>::listempty()
{
	if(head==NULL)
		return 1;
	else
		return 0;
}
template <class T>
T list<T>::Delete()//delete from front
{
   T x;
   node<T> *p;
	if(head==NULL)
	{
		return 0;
	}
	else
	{
		x=head->data;
		p=head;
		head=head->next;
	}
	delete(p);
	return x;
}
template <class T>
void list<T>::insert(T d)//insert from front
{
	node<T> *temp=NULL;;
	temp=new node<T>;
	temp->data=d;
			temp->next=head;
			head=temp;
}

template <class T>
void list<T>::displayList()//to show list
{
	node<T> *temp=NULL;

	temp=head;
  if(head==NULL)
	  cout<<"NULL";
		while(temp!=NULL)//repeate until end of list
		{
			cout<<temp->data;
			cout<<" ";
			temp=temp->next;
		}

}

template <class T>
T list<T>::topData()//to take data of stack top
{
	if(head==NULL)
	{
		return 0;
	}
	return head->data;
}
