//============================================================================
// Name         : StackLinkedList.cpp
// Author      : SOHAIL MOMIN
// Version     :
// Copyright   : Your copyright notice
// Description : Hello World in C++, Ansi-style
//============================================================================

#include <iostream>
#include "Stack.h"
using namespace std;

//Definitions of operation function on stack
template <class T>
void Stack<T>::push(T a)
{
	lc.insert(a);
}
template <class T>
bool Stack<T>::isempty()
{
	if(lc.listempty()==1)
		return (1);
	return 0;
}

template <class T>
void Stack<T>::display()
{
		lc.displayList();
}
template <class T>
T Stack<T>::pop()
{

	if(isempty()==1)
	{
			return 0;
	}
	else
	{
   return lc.Delete();
	}
  }

template <class T>
T Stack<T>::TopData()
{

	return lc.topData();

}

