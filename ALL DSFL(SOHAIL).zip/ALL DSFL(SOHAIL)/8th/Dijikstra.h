/*
 * Dijikstra.h
 *
 *  Created on: Mar 26, 2016
 *      Author: SOHAIL MOMIN
 */

#ifndef DIJIKSTRA_H_
#define DIJIKSTRA_H_

class Graph_Dijikstra
{
public :
	int graph_Cost_mat[20][20];
	int Ver,edges;
	char V_name[20];
	void inputGraph();
	void dijikstra();
};




#endif /* DIJIKSTRA_H_ */
