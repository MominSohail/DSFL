//============================================================================
// Name        : Dijikstra.cpp
// Author      : SOHAIL
// Version     :
// Copyright   : Your copyright notice
// Description : Hello World in C++, Ansi-style
//============================================================================

#include <iostream>
#include "Dijikstra.h"
using namespace std;

void Graph_Dijikstra::inputGraph()
{
	int i,j;
	cout<<"\nEnter Total number of Vertices :";
	cin>>Ver;
	cout<<"\nEnter Number of Edges U Have in ur Graph :";
	cin>>edges;

	for(i=0;i<Ver;i++)
	{
		cout<<"\n Enter Names of Vertex "<<i+1<<":";
		cin>>V_name[i];
	}
	for(i=0;i<Ver;i++)//initialize adjacency Matrix
	{
		for(j=0;j<Ver;j++)
		{
			if(i==j)
			graph_Cost_mat[i][j]=0;
			else
			graph_Cost_mat[i][j]=32767;
		}
	}
	char temp;
	for(i=0;i<edges;i++)
	{
	cout<<"\nEnter Start vertex of Edge "<<i+1<<": ";
	cin>>temp;
	int S=-1,E=-1; //initialize start and End
	j=0;
	 while(j<Ver && S==-1)//to avoid duplication of edges
	 {
		 if(V_name[j]==temp)
		 {
		      	 S=j;
		     cout<<"\nEnter End of Edge "<<i+1<<":";
		     cin>>temp;
		     j=0;
		     while(j<Ver && E==-1)
		     {
		       if(V_name[j]==temp)
		       {
		    	   E=j;
		    	   if(graph_Cost_mat[S][E]==32767 && graph_Cost_mat[E][S]==32767)
		    	   {
		    		   cout<<"\nEnter graph_Ad_mat of Edges "<<V_name[S]<<"-"<<V_name[E]<<":";
		    		    cin>>graph_Cost_mat[S][E];  //enter graph_Ad_mat of edge in adjacency matrix
		    		    graph_Cost_mat[E][S]=graph_Cost_mat[S][E];//undirected graph
		    	   }
		    	   else
		    	   {
		    		   cout<<"\nEdge Already Present ";
		    		   j=Ver;
		    		   i--; //decrement to take edge again
		    	   }
		       }
		       j++;
		     }
		 }
		 j++;
	 }
	 if(S==-1 || E==-1)//if wrong vertex name given
	 {
	 cout<<"\nThere is NO such  of Vertex... ";
	 i--;
	 }
	}
	cout<<"\nGraph Created ";
}

void Graph_Dijikstra::dijikstra()
{
	int Dist[10],Pred[10],visited[10],count, min,next,i,j,u;
	char sorce;
	int f=0;
	while(f==0)
	{
	cout<<"\n Enter Source Node :";
	cin>>sorce;
	for(i=0;i<Ver;i++)
	{
		if(sorce==V_name[i])
			{u=i; f=1;}
	}
	 if(f==0)
		 {cout<<"\n Given Node is not in Graph..!";
	 cout<<"\n Re _Enter..";}
	}
	for(i=0;i<Ver;i++)
	{
		Dist[i]=graph_Cost_mat[u][i];
		Pred[i]=u;
		visited[i]=0;
	}

	Dist[u]=0;
	visited[u]=1;
	count=1;
	while(count<Ver-1)
	{
		min=32767;
		for(i=0;i<Ver;i++)
		{
			if(Dist[i]<min && visited[i]==0)
			{
				min=Dist[i];
				next=i;
			}
		}
			visited[next]=1;
			for(i=0;i<Ver;i++)
			{
				if(visited[i]==0)
				{
					if(min+graph_Cost_mat[next][i] <Dist[i])
					{
						Dist[i]=min+graph_Cost_mat[next][i];
						 Pred[i]=next;
					}
				}
			}

		count++;
	}

	cout<<"\nShortest Distance From "<<V_name[u]<<" to Other All Nodes of Graph...";
	for(i=0;i<Ver;i++)
	{
		if(i!=u)
		{
			cout<<"\nShortest Distance From "<<V_name[u]<<"Node To "<<V_name[i]<<" Node for this Total Weight "<<Dist[i];
			cout<<"\nHence Path is  "<<V_name[i];
			j=i;
			do
			{
				j=Pred[j];
				cout<<"<-"<<V_name[j];
			}while(j!=u);
		}
	}
}

int main() {

	Graph_Dijikstra Di;
	int c=0;
		while(c<3)
		{
			cout<<"\n1.Take Graph :\n2.Find Shortest Path By Dijikstra's Algorithm\n3.Exit";
			cout<<"\nEnter your choice:";
			cin>>c;
			switch(c)
			{
			case 1:
				Di.inputGraph();

				break;
			case 2:
				 Di.dijikstra();
				break;

			case 3:
				return 0;
				break;

			}
		}

		return 0;
}
