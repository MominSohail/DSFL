//============================================================================
// Name        : Queue.cpp
// Author      : SOHAIL
// Version     :
// Copyright   : Your copyright notice
// Description : Hello World in C++, Ansi-style
//============================================================================

#include <iostream>
#include "Queue.h"
using namespace std;
//Function definition for Queue member function
int Queue::isEmpty()//to check for empty queue
{
	if(front==-1 && rear==-1)//condition to check for empty Queue
		return 1;
	return 0;
}
int Queue::isFull()
{
	if((rear+1)%max==front)//condition to check full Queue
		return 1;
	 return 0;
}
int Queue::EnQueue(int x)//to insert element in queue
{
	if(isEmpty()==1)//when Queue is empty
	{
		front=rear=0;
		Q[rear]=x;
	}
	else if(isFull()==1)
	{
		cout<<"\nQueue Is OverFlow ";
		return 0;
	}
	else
	{
		rear=(rear+1)%max;//Special increment of rear in circular queue
		Q[rear]=x;

	}
	return 1;
}

int Queue::DeQueue()
{
	int x=0;
	if(isEmpty()==1)
	{
		cout<<"\nQueue is Empty";
	}
	else
	{
		x=Q[front];
		if(rear==front)
				{
					EmptyQueue();
				}
		else
		front=(front+1)%max;//special increment of front
		                    //after deletion in circular queue
	}
	return x;
}

void Queue::display() //to show contain of queue
{
	int i;
	if(isEmpty()==1)//check for empty
	{
		cout<<"\nQueue is Empty";
	}

	else
	{
		i=front;//display from front to rear
		cout<<"\n "<<Q[i]<<"<-Front";
		if(i==rear)
			cout<<"<-Rear";
		if(i!=rear)
		{
            do
			{
				i=(i+1)%max;//increamt for i in circular Queue
			cout<<"\n "<<Q[i];
			}while(i!=rear);
           cout<<"<-Rear";
		}
	}
}
int main() {
	int c=0,e;
	Queue Q;//object to Queue
	while(c<5)//case to select operation on Circular Queue
	{
		cout<<"\n";
	cout<<"\n1.Create Queue \n2.Insert in Queue \n3.Delete From Queue \n4.Display ";
	cout<<"\nNOTE: Maximum size ofCircular Queue is 4";
	cout<<"\nEnter Your Choice :";
	cin>>c;
	switch(c)
	{
	case 1:
		    Q.EmptyQueue();//create empty queue
		    cout<<"\n An Empty Queue is Created ";
		break;
	case 2:
		if(Q.isFull()==1)//check is queue is empty
			{
				cout<<"\nQueue OverFlow";
			}
		else
		{
		  cout<<"\n Enter Integer Elements to insert in Queue";
		  cin>>e;
		   if(Q.EnQueue(e)==1)//condition check and call to insert
			   cout<<"\nOne Element is Inserted ";//function to insert element

		}
		   break;
	case 3:
		  e=Q.DeQueue();//to delete element of queue
		  if(e!=0)
		  {
		  cout<<"\n One element From Queue is Deleted";
		  cout<<"\nAfter Deletion your Circular Queue :";
		     Q.display();
		  }
		  break;
	case 4:
		cout<<"\nQueue Elements Are:";
		Q.display(); //display contain of Queue
		break;
	}
	}
	return 0;
}
