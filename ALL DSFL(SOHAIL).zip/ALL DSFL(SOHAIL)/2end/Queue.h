/*
 * Queue.h
 *
 *  Created on: 01-Jan-2016
 *      Author: pict
 */

#ifndef QUEUE_H_
#define QUEUE_H_
#define max 4 //micro to declare max size
// Prototype declaration for circular Queue
class Queue//class for Circular Queue
{
public:
	int Q[max]; //max Circular Queue size
	int front,rear;
	Queue()//constructor for initialization of front and rear
	{
		front=-1;
		rear=-1;
	}
	//member function for Queue Operation
	void EmptyQueue(){front=-1;
	            rear=-1;};
	int isEmpty();
	int isFull();
	int EnQueue(int x);
	int DeQueue();
	void display();

};

#endif /* QUEUE_H_ */
