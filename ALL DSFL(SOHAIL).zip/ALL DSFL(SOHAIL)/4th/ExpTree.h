/*
 * ExpTree.h
 *
 *  Created on: Feb 6, 2016
 *      Author: SOHAIL MOMIN
 */

#ifndef EXPTREE_H_
#define EXPTREE_H_
#include "Stack.h"
#include "List.h"
#include <iostream>
class Exp
{
public:
	Stack S;
	node *RootPost;
	node *RootPre;
	Exp()  //constructor
	{
		RootPost=NULL;
		RootPre=NULL;
	}
	//function prototype for creation of tree
	void createPostT(char expPost[]);
	void createPreT(char expPre[]);

	//prototype for Traversing tree
	void Recursive_Tra_Post();
	void Recursive_Tra_Pre();

    void Rec_Inorder(node *T);
    void Rec_Preorder(node *T);
    void Rec_Postorder(node *T);

    void Non_Recursive_Post();
    void Non_Recursive_Pre();

    void N_Rec_Inorder(node *T);
        void N_Rec_Preorder(node *T);
        void N_Rec_Postorder(node *T);
};




#endif /* EXPTREE_H_ */
