/*
 * Stack.cpp
 *
 *  Created on: Feb 6, 2016
 *      Author: SOHAIL MOMIN
 */
#include<iostream>
#include "Stack.h"
using namespace std;
void Stack::push(node *Tnode)
{
	li.insert(Tnode);
}

node *Stack::pop()
{
	return li.del();
}

bool Stack::isEmpty()
{
	return li.isempty();
}
