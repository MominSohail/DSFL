/*
 * Stack.h
 *
 *  Created on: Feb 6, 2016
 *      Author: SOHAIL MOMIN
 */

#ifndef STACK_H_
#define STACK_H_
#include "List.h"
class Stack
{
public:
	List li;
	void push(node *Tnode);
	node *pop();
	bool isEmpty();
};




#endif /* STACK_H_ */
