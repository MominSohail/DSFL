//============================================================================
// Name        : ExpTree.cpp
// Author      : SOHAIL
// Version     :
// Copyright   : Your copyright notice
// Description : Hello World in C++, Ansi-style
//============================================================================

#include <iostream>
#include <String.h>
#include "ExpTree.h"
#include "List.h"
using namespace std;

void Exp::createPostT(char expPost[])//function to create Postfix Expression Tree
{
  char c;
  int i=0;

  while(expPost[i]!='\0')//scan from left to right
  {
	  c=expPost[i];
	  RootPost=new node;
	  RootPost->data=c;
	  if(isalnum(c))  //if Operand
	  {
           RootPost->Lchild=RootPost->Rchild=NULL;
           S.push(RootPost);
	  }
	  else  ///if operator  pop two operand and join to operand
	  {
		  RootPost->Rchild=S.pop();
		  RootPost->Lchild=S.pop();
          S.push(RootPost);
	  }
	  i++;
  }
  RootPost=S.pop();
  cout<<"\nPostFix Tree Created whose Root is->"<<RootPost->data<<endl;
}
void Exp::createPreT(char expPre[])//to create Post Fix expression tree
{
	 int l;
	l=strlen(expPre); //to find length
	l--;
	while(l>=0) //scan from right to left
	{
     RootPre=new node;
      RootPre->data=expPre[l];
      if(isalnum(expPre[l]))//if operand
      {
    	  RootPre->Lchild=RootPre->Rchild=NULL;
    	  S.push(RootPre);
      }
      else//if operand
      {
    	  RootPre->Lchild=S.pop();
    	  RootPre->Rchild=S.pop();
    	  S.push(RootPre);
      }
		l--;
	}
	RootPre=S.pop();
	  cout<<"\nPreFix Tree Created whose Root is->"<<RootPre->data<<endl;
}

void Exp::Recursive_Tra_Post()//for Recursive Traversal post fix
{
	cout<<"\nRecursive Inorder Traverse:";
	Rec_Inorder(RootPost);
	cout<<"\nRecursive Preorder Traverse:";
	Rec_Preorder(RootPost);
	cout<<"\nRecursive Postorder Traverse:";
		Rec_Postorder(RootPost);
}

void Exp::Recursive_Tra_Pre()//recursive traversaL FOR PREFIX
{
	cout<<"\nRecursive Inorder Traverse:";
	Rec_Inorder(RootPre);
	cout<<"\nRecursive Preorder Traverse:";
	Rec_Preorder(RootPre);
	cout<<"\nRecursive Postorder Traverse:";
		Rec_Postorder(RootPre);
}

//traversal inorder ,post order and Preorder recursively
void Exp:: Rec_Inorder(node *T)
{
	if(T!=NULL)
	{
		Rec_Inorder(T->Lchild);
		cout<<T->data;
		Rec_Inorder(T->Rchild);
	}
}
 void Exp::Rec_Preorder(node *T)
 {
	 if(T!=NULL)
	 	{
	 		cout<<T->data;
	 		Rec_Preorder(T->Lchild);
	 		Rec_Preorder(T->Rchild);
	 	}
 }
 void Exp:: Rec_Postorder(node *T)
 {
 	if(T!=NULL)
 	{
 		Rec_Postorder(T->Lchild);
  		Rec_Postorder(T->Rchild);
  		cout<<T->data;
 	}
 }


 void Exp::Non_Recursive_Post()//non recursive traversal post fix exp
 {
 	cout<<"\nNon_Recursive Inorder Traverse:";
 	N_Rec_Inorder(RootPost);
 	cout<<"\nNon_Recursive Preorder Traverse:";
     N_Rec_Preorder(RootPost);
 	cout<<"\nNon_Recursive Postorder Traverse:";
           N_Rec_Postorder(RootPost);
 }

 void Exp::Non_Recursive_Pre()//non recursive prefix wxp
 {
 	cout<<"\nNon Recursive Inorder Traverse:";
 	N_Rec_Inorder(RootPre);
 	cout<<"\nNon Recursive Preorder Traverse:";
 	N_Rec_Preorder(RootPre);
 	cout<<"\nNon_Recursive Postorder Traverse:";
 		N_Rec_Postorder(RootPre);
 }
//function definition for non recursive traversal
 void Exp:: N_Rec_Postorder(node *T)
 {	node *previous;
 previous=T;
 if(T==NULL)
 {
   cout<<"\nTree is Empty";
   return;
 }
 S.push(T);
 while(S.isEmpty()==0)
 {
 	T=S.pop();
 	if(T->Rchild==NULL && T->Lchild==NULL)
 	{
 		cout<<T->data;
 		previous=T;
 	}
 	else
 	{
 		if(T->Rchild==previous || T->Lchild==previous)
 		{
 			previous=T;
 			cout<<previous->data;
 		}
 		else
 		{
 			S.push(T);
 			if(T->Rchild!=NULL)
 				S.push(T->Rchild);
 			if(T->Lchild!=NULL)
 				S.push(T->Lchild);
 		}
 	}
 }

}
 void Exp:: N_Rec_Inorder(node *T)
 {

	if(T==NULL)
	{
		cout<<"\nTree is Empty";
	return ;
	}
	else
	{
		while(T!=NULL)
		{
			S.push(T);
			T=T->Lchild;
		}
		while(S.isEmpty()==0)
		{
			T=S.pop();
			cout<<T->data;
			T=T->Rchild;
			while(T!=NULL)
			{
				S.push(T);
				T=T->Lchild;
			}
		}

	}
 }
 
void Exp:: N_Rec_Preorder(node *T)
{
	if(T==NULL)
	{
		cout<<"\nTreeis Empty";
	  return ;
	}
	else
	{
		while(T!=NULL)
		{
			cout<<T->data;
			S.push(T);
			T=T->Lchild;
		}
		while(S.isEmpty()==0)
		{
			T=S.pop();
			T=T->Rchild;
			while(T!=NULL)
			{
				cout<<T->data;
				S.push(T);
				T=T->Lchild;
			}
		}
	}
}

int main() {
	Exp E;
	char expPost[20];
	char expPre[20];
	int c=0;
	while(c<=5)
	{
		cout<<"\n\n1.Create Post Fix Expression Tree\n2.Create PreFixExpression Tree";
        cout<<"\n3.Recursive Traversing \n4.Non_Recursive Traversing \n5.Exit";
		cout<<"\nEnter Your Choice";
		cin>>c;
        switch(c)
        {
        case 1: cout<<"\nEnter PostFix Expression";
            	cin>>expPost;
    	        E.createPostT(expPost);
    	break;
        case 2:
        	cout<<"\nEnter PreFix Expression";
        	cin>>expPre;
        	   E.createPreT(expPre);
        	break;
        case 3:
        	cout<<"\n\nRecursive Traversing of PostFix Expression Tree:";
        	 E.Recursive_Tra_Post();

        	 cout<<"\n\nRecursive Traversing of PreFix Expression Tree:";
        	 E.Recursive_Tra_Pre();
        	break;
        case 4:
        	cout<<"\n\nNON_Recursive Traversing of PostFix Expression Tree:";
        	 E.Non_Recursive_Post();
        	 cout<<"\n\nNON_Recursive Traversing of PreFix Expression Tree:";
        	 E.Non_Recursive_Pre();
        	break;
        case 5:
        	return 0;
        			break;
        default:cout<<"\nIncorrect Choice";
        }
	}

	return 0;
}
