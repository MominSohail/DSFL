/*
 * List.cpp
 *
 *  Created on: Feb 6, 2016
 *      Author: SOHAIL MOMIN
 */

#include<iostream>
#include "List.h"
using namespace std;
void List::insert(node *Tnode)
		{
    	  StackData[++top]=Tnode;
	    }
node* List::del()
{
   return StackData[top--];
}

bool List::isempty()
{
	if(top==-1)
		return 1;
	return 0;
}

