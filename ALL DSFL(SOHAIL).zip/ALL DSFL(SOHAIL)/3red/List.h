/*
 * List.h
 *
 *  Created on: Jan 16, 2016
 *      Author: SOHAIL MOMIN
 */

#ifndef LIST_H_
#define LIST_H_
#include<iostream>
struct patient
	{
	int Sr_No;
		char name[20];
		int age;
		char gender[20];
	};
struct node
{
	patient p;
   struct node *next=NULL;
};

class List
{
public:
	node *F,*R;
	List()
	{
		F=NULL;
		R=NULL;
	}
	void EnQueue(struct patient x);
	bool isEmptyQ();
	struct patient DeQueue();
	void display();
};



#endif /* LIST_H_ */
