/*
 * PriorityQueue.h
 *
 *  Created on: Jan 16, 2016
 *      Author: SOHAIL MOMIN
 */

#ifndef PRIORITYQUEUE_H_
#define PRIORITYQUEUE_H_
#include "List.h"
class PQueue
{
public:
	List PQ[3];
	void admit();
	void show();
  void Service();
};




#endif /* PRIORITYQUEUE_H_ */
