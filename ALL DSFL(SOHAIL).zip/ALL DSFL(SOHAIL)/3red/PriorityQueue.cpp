#include "List.h"
#include "PriorityQueue.h"
#include <iostream>
using namespace std;

void PQueue::admit()
{
 patient x;
 int choice,c;
 int f=0,f2=0;
 while(f==0)
 {
		 f=1;
 cout<<"\n1.Serious \n2.Medium illness \n3.General "<<endl;
 cout<<"\nEnter Type of Patient:"<<endl;
 cin>>choice;
  if(choice>3 || choice <1)
  {
	  cout<<"\nEnter Valid Input";
	f=0;
  }
		 }

 cout<<"\nEnter Name of Patient";
 cin>>x.name;
 cout<<"\nEnter Register Number";
 cin>>x.Sr_No;
 cout<<"\nEnter Age";
 cin>>x.age;
 cout<<"\nEnter Gender: \n1.Male \n2.Female \n3.Other";
 cin>>x.gender;

 switch(choice)
 {
 case 1:
	   PQ[0].EnQueue(x);
	 break;
 case 2:
 	   PQ[1].EnQueue(x);
 	 break;
 case 3:
 	   PQ[2].EnQueue(x);
 	 break;
 default:
	 cout<<"\nEnter Correct Choice";

 }
  }

void PQueue::show()
{
	cout<<"\nSerious Patient List:";
	 PQ[0].display();
	 cout<<"\n<------------------------------------------------------->";
	 cout<<"\n\nMedium Illness Patient List:";
	 	 PQ[1].display();
	 	cout<<"\n<------------------------------------------------------->";
	 	cout<<"\n\nGeneral Patient List:"<<endl;
	 		 PQ[2].display();
}

void PQueue:: Service()
		{
	      patient p;
	      int i=0;
	      while(i<3 && PQ[i].isEmptyQ()==1)
	    	  i++;
	      if(i==3)
	    	  cout<<"\nNo one is here";
	      else
	      {
	    	  p=PQ[i].DeQueue();
	    	  cout<<"\nSerivce Provided to ";
	    	    if(i==0)
	    	    	cout<<"Serious Patient ";
	    	    else if(i==1)
	    	    	cout<<"Medium Illness Patient ";
	    	    else
	    	    	cout<<"General Patient ";
	    	  cout<<"whose Details is:";
	    	  cout<<"\nSr_No.\tName \tAge \tGender";
	    	  cout<<"\n"<<p.Sr_No<<"\t"<<p.name<<"\t"<<p.age<<"\t"<<p.gender;
	      }


		}
int main() {

	PQueue pq;
	int c=0;
	while(c!=4)
	{
	cout<<"\n1.Admit Patient(Take Entry) \n2.Show All Patients \n3.Provide Service \n4.Exit";
	cout<<"\nEnter Your Choice :";
	cin>>c;
	switch(c)
	{
	case 1:
		  pq.admit();
		break;
	case 2:
		 pq.show();
		break;
	case 3:
		pq.Service();
		break;
	default: cout<<"\nEnter Proper choice";
	}
	}

	return 0;
}
