/*
 * List.cpp
 *
 *  Created on: Jan 16, 2016
 *      Author: SOHAIL MOMIN
 */
#include "List.h"
#include<iostream>
using namespace std;

void List::EnQueue(struct patient x)
{

   if(F==NULL)
   {
	   R=new node ;
	   R->p=x;
	   //R->next=NULL;
	   F=R;
   }
   else
   {
	   R->next=new node;
	   R=R->next;
	   R->p=x;
	   //R->next=NULL;
   }
   cout<<"Saved";
}

bool List::isEmptyQ()
{
	if(F==NULL)
	{
		return 1;
	}
	else
		return 0;
}

struct patient List::DeQueue()
{
	node *temp=NULL;
	patient pe;
	if(isEmptyQ()==1)
		cout<<"\nQueue is Empty";
	else
	{
		pe=F->p;
		temp=F;
	     F=F->next;
	     if(F==NULL)
	    	 R=NULL;
	     delete(temp);
	     cout<<"DeQueued";
	}
	return pe;
}
void List::display()
{
	node *n;
	if(isEmptyQ()==1)
	{
		cout<<"\nNo One is there in Queue";
	}
	else
	{
		cout<<"\nSr_No.\tName \tAge \tGender";
        n=F;
        while(n!=NULL)
        {
        	cout<<"\n"<<n->p.Sr_No<<"\t"<<n->p.name<<"\t"<<n->p.age<<"\t"<<n->p.gender;
        	n=n->next;
        }
	}
}


