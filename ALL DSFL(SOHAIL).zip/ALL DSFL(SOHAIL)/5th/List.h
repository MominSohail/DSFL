/*
 * List.h
 *
 *  Created on: Feb 6, 2016
 *      Author: SOHAIL MOMIN
 */

#ifndef LIST_H_
#define LIST_H_
#include <iostream>
struct node
{
	int data;
	 node *Rchild=NULL;
	 node *Lchild=NULL;
};

class List
{
public :
	node *StackData[20];
	int top;
	List()
	{
		top=-1;
	}
	void insert(node *Tnode);
    node *del();
    bool isempty();
};
#endif /* LIST_H_ */
