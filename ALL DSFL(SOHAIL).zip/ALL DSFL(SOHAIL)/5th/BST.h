/*
 * BST.h
 *
 *  Created on: Feb 10, 2016
 *      Author: SOHAIL MOMIN
 */

#ifndef BST_H_
#define BST_H_
#include "List.h"
#include "Queue.cpp"
#include "Stack.h"
#include <iostream>

class BST
{
public :
	node *Root,*pre;

	queue Q;
	Stack S;
	BST()
	{
		Root=NULL;
		pre=NULL;
	}
	void create();
	bool insert(int x);

	node *Rec_search(node *Root,int key);
	void Non_Rec_search(int key);

	void Tra_Levelorder();

	void Recu_Tra();
	void Rec_Inorder(node *T);
	void Rec_Preorder(node *T);
	void Rec_Postorder(node *T);

	void Non_Recu_Tra();
		void Non_Rec_Inorder(node *T);
		void Non_Rec_Preorder(node *T);
		void Non_Rec_Postorder(node *T);

	int Non_Rec_Height();

	void Rec_Mirror(node *Root);
	void Itra_Mirror();


	node *Delete(int x,node *T);
	node *min(node *T);

	int MaxEle();
};

#endif /* BST_H_ */
