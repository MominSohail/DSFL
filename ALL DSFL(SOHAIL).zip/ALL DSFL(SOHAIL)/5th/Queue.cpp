/*
 * Queue.cpp
 *
 *  Created on: Feb 11, 2016
 *      Author: SOHAIL MOMIN
 */
#include "List.h"
class queue		//CLASS QUEUE
{
	node *arr[20];
	int r,f;
	public:
		queue()
		{
			f=r=-1;
		}
		int empty()
		{
			if(f==-1 && r==-1)
				return 1;
			return 0;
		}
		int size()
		{
			int c=1,t;
			if(empty()==1)
				c=0;
			t=f;
			while(t!=r)
			{
				t++;
				c++;
			}
			return c;
		}
		void enqueue(node *x)
		{
			if(f==-1)
			{
				f=r=0;
			}
			else
			{
				r++;
			}
			arr[r]=x;
		}
		node* dequeue()
		{
			node *x;
			if(f!=-1)
			{
				x=arr[f];
				if(f==r)
					f=r=-1;
				else
					f++;
			}
			return x;
		}
		void init()
		{
			f=r=-1;
		}
};



