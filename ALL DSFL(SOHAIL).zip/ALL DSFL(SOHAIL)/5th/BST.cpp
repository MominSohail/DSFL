//============================================================================
// Name        : BST.cpp
// Author      : SOHAIL
// Version     :
// Copyright   : Your copyright notice
// Description : Hello World in C++, Ansi-style
//============================================================================

#include <iostream>
using namespace std;
#include "BST.h"
#include "List.h"

void BST::create()
{
	int i,n,d;
	cout<<"\nHow many Nodes you have :";
	cin>>n;
    for(i=1;i<=n;i++)
    {
    	cout<<"\nEnter "<<i<<" Node Data";
    	cin>>d;
    	if(insert(d)==0)
    		i--;
    }
    cout<<"\nBST Created";
}
bool BST::insert(int x)
{
	node *temp=NULL,*p=NULL,*q=NULL;
	        temp=new node;
			temp->data=x;
			//cout<<"\nYour data"<<temp->data;
			if(Root==NULL)
	    	 {
				Root=new node;
				Root=temp;
            return 1;
	    	 }
	        else
			{
				q=p=Root;
	         while(p!=NULL)  //find correct place
	         {
	        	 q=p;
	        	 if(x>p->data)
	        		 p=p->Rchild;
	        	 else if(x<p->data)
	        		 p=p->Lchild;
	        	 else
	        	 {
	        		 cout<<"\nDublication not Allowed";
	        		 return 0;
	        	 }
	         }
	            if(temp->data>q->data)
	            	{
	            	q->Rchild=temp;
	            	return 1;
	            	}
	            else
	            {
	            	q->Lchild=temp;
	            	return 1;
	            }
			}
			return 0;
		}


node *BST::Rec_search(node *Root,int key)
{
	node *temp=NULL;
	if(Root==NULL)
	{
		cout<<"\nBST is Empty";
		return 0;
	}
	else
	{
		temp=Root;
		if(temp->data==key)
		{
			cout<<"\nGiven Element FOUND in BST";
			return temp;
		}
		else if(key<temp->data)
		{
			if(temp->Lchild==NULL)
				{
				cout<<"\nGiven Element NOT Found in BST";
				return temp;
				}
			else
		        temp=Rec_search(temp->Lchild,key);
		}
		else
		{
			if(temp->Rchild==NULL)
				{
				cout<<"\nGiven Element NOT Found in BST";
				return temp;
				}
			temp=Rec_search(temp->Rchild,key);
		}

	}
	return temp;
}
void BST::Non_Rec_search(int key)
{
	node *temp;
  if(Root==NULL)
  {
	  cout<<"\nBST is Empty";
	  return ;
  }
  else
  {
	  temp=Root;
	  while(temp!=NULL)
	  {
		  if(key==temp->data)
		  {
			  cout<<"\nGiven Element FOUND in BST";
			  return ;
		  }
		  else if(temp->data>key)
			  temp=temp->Lchild;
		  else
			  temp=temp->Rchild;
	  }
	  cout<<"\n Given Element NOT Found";
  }

}
void BST::Tra_Levelorder()
{
	node *temp=NULL;
	if(Root==NULL)
	{
		cout<<"\nBST Is Empty";
		return ;
	}
	else
	{
		cout<<"\nLevel Order Traversal : ";
        temp=Root;
          Q.enqueue(temp);
          while(Q.empty()==0)
          {
        	  temp=Q.dequeue();
        	  cout<<temp->data<<"\t";
        	  if(temp->Lchild!=NULL)
        		  Q.enqueue(temp->Lchild);
        	  if(temp->Rchild!=NULL)
        		  Q.enqueue(temp->Rchild);
          }
	}
}

void BST::Recu_Tra()//recursive traversaL FOR PREFIX
{
   cout<<"\nRecursive Inorder Traverse:";
   Rec_Inorder(Root);
   cout<<"\nRecursive Preorder Traverse:";
   Rec_Preorder(Root);
   cout<<"\nRecursive Postorder Traverse:";
   Rec_Postorder(Root);
}
//traversal inorder ,post order and Preorder recursively
void BST:: Rec_Inorder(node *T)
{
if(T!=NULL)
{
Rec_Inorder(T->Lchild);
cout<<"\t"<<T->data;
Rec_Inorder(T->Rchild);
}
}
void BST::Rec_Preorder(node *T)
{
if(T!=NULL)
{
cout<<"\t"<<T->data;
Rec_Preorder(T->Lchild);
Rec_Preorder(T->Rchild);
}
}
void BST:: Rec_Postorder(node *T)
{
if(T!=NULL)
{
Rec_Postorder(T->Lchild);
Rec_Postorder(T->Rchild);
cout<<"\t"<<T->data;
}
}


void BST::Non_Recu_Tra()//non recursive traversal post fix exp
 {
 	cout<<"\nNon_Recursive Inorder Traverse:";
 	Non_Rec_Inorder(Root);
 	cout<<"\nNon_Recursive Preorder Traverse:";
     Non_Rec_Preorder(Root);
 	cout<<"\nNon_Recursive Postorder Traverse:";
           Non_Rec_Postorder(Root);
 }
void BST:: Non_Rec_Postorder(node *T)
 {	node *previous;
 previous=T;
 if(T==NULL)
 {
   cout<<"\nTree is Empty";
   return;
 }
 S.push(T);
 while(S.isEmpty()==0)
 {
 	T=S.pop();
 	if(T->Rchild==NULL && T->Lchild==NULL)
 	{
 		cout<<"\t"<<T->data;
 		previous=T;
 	}
 	else
 	{
 		if(T->Rchild==previous || T->Lchild==previous)
 		{
 			previous=T;
 			cout<<"\t"<<previous->data;
 		}
 		else
 		{
 			S.push(T);
 			if(T->Rchild!=NULL)
 				S.push(T->Rchild);
 			if(T->Lchild!=NULL)
 				S.push(T->Lchild);
 		}
 	}
 }

 }
 void BST:: Non_Rec_Inorder(node *T)
 {

	if(T==NULL)
	{
		cout<<"\nTree is Empty";
	return ;
	}
	else
	{
		while(T!=NULL)
		{
			S.push(T);
			T=T->Lchild;
		}

		while(S.isEmpty()==0)
		{
			T=S.pop();
			cout<<"\t"<<T->data;
			T=T->Rchild;
			while(T!=NULL)
			{
				S.push(T);
				T=T->Lchild;
			}
		}

	}
 }
void BST:: Non_Rec_Preorder(node *T)
{
	if(T==NULL)
	{
		cout<<"\nTreeis Empty";
	  return ;
	}
	else
	{
		while(T!=NULL)
		{
			cout<<"\t"<<T->data;
			S.push(T);
			T=T->Lchild;
		}
		while(S.isEmpty()==0)
		{
			T=S.pop();
			T=T->Rchild;
			while(T!=NULL)
			{
				cout<<"\t"<<T->data;
				S.push(T);
				T=T->Lchild;
			}
		}
	}
}


int BST::Non_Rec_Height()
{
	int h=0,node_count=0;
	node *temp;
	if(Root==NULL)
	{
		cout<<"\nEmpty BST";
		return 0;
	}
	else
	{
	temp=Root;
	Q.init();
	Q.enqueue(temp);
	while(1)
	{
		node_count=Q.size();
		if(node_count==0)
			return h;
		h++;
		while(node_count>0)
		{
			temp=Q.dequeue();
			if(temp->Lchild!=NULL)
				Q.enqueue(temp->Lchild);
			if(temp->Rchild!=NULL)
				Q.enqueue(temp->Rchild);
			node_count--;
		}
	}
	}
	return h;
}

void BST::Rec_Mirror(node *Root)
{
	node *temp=NULL;
	if(Root)
	{
		temp=Root->Rchild;
		Root->Rchild=Root->Lchild;
		Root->Lchild=temp;
		Rec_Mirror(Root->Lchild);
		Rec_Mirror(Root->Rchild);
	}

}

void BST:: Itra_Mirror()
{
	if(Root==NULL)
	{
		cout<<"\nEmpty BST";
		return ;
	}
	else
	{
	   Q.init();
		node *temp,*temp2;
		temp=Root;
		Q.enqueue(temp);
	while(Q.empty()==0)
	{
		temp=Q.dequeue();
		if(temp->Lchild==NULL && temp->Rchild==NULL)
			continue;
		if(temp->Lchild!=NULL && temp->Rchild!=NULL)
		{
			temp2=temp->Lchild;
			temp->Lchild=temp->Rchild;
			temp->Rchild=temp2;
			Q.enqueue(temp->Lchild);
			Q.enqueue(temp->Rchild);
		}
		else if(temp->Lchild==NULL)
		{
			temp->Lchild=temp->Rchild;
			temp->Rchild=NULL;
			Q.enqueue(temp->Lchild);
		}
		else
		{
			temp->Rchild=temp->Lchild;
			temp->Lchild=NULL;
			Q.enqueue(temp->Rchild);
		}
	}
	cout<<"\nMirror of BST DONE Iteratively";
	}
}

node *BST::min(node *T)
{
	node *temp;
	temp=T;
 if(temp->Lchild==NULL)
 {
	// pre=T;
	 return temp;
 }
 else
 {
	 pre=temp;
	 return min(temp->Lchild);
 }
}


node * BST::Delete(int x,node *root)
{

	node *temp=NULL,*T=NULL,*p=NULL;
	int del;
	p=T=root;
	if(T==NULL)
	{
		cout<<"Empty tree";
	}
		else
		{
			while(T!=NULL && T->data!=x)//searching for deleting element
				{
				if(x<T->data)
				{
					p=T;
			           T=T->Lchild;
				}
			    else if(x>T->data)
			           {
			        	   p=T;
						T=T->Rchild;
			           }
				}
			if(T==NULL)//when not found
			{
				cout<<"\nGiven Element NOT FOUND";
			  return temp;
			}
			if(p==T && T->Lchild==NULL && T->Rchild==NULL )//when Root Node deletion having no child
			{
				Root=NULL;
				cout<<"\nBSt Become Empty ";
				return T;
			}
			if(T->Lchild!=NULL && T->Rchild!=NULL)//deletion when Two child
			{
				pre=T;
                     temp=min(T->Lchild);
                     del=T->data;
                    T->data=temp->data;
                    temp->data=del;
                    if(pre->Lchild==temp)
                    {
                    	pre->Lchild=NULL;
                    }
                    else if(pre->Rchild!=NULL)
                    {

                    	pre=pre->Rchild;
                    }
                  return temp;
			}
			else
			{
			  temp=T;
				if(T->Lchild==NULL && T->Rchild!=NULL)//deletion when there is Right one Child
					{
                     del=T->data;
					T->data=T->Rchild->data;
					temp=T->Rchild;
					temp->data=del;
					 T->Rchild=NULL;
					}
				else if(T->Rchild==NULL && T->Lchild!=NULL)//Deletion when there is Left one Child
					{
                      del=T->data;
					T->data=T->Lchild->data;
					temp=T->Lchild;
					temp->data=del;
					T->Lchild=NULL;
					}
				else                           //deletion when no child node
					if(p->Rchild==temp)
					{
						temp=p->Rchild;
						p->Rchild=NULL;
					}
					else
					{
						temp=p->Lchild;
					 	p->Lchild=NULL;
					}
			}

		}
    return temp;
	}

int BST::MaxEle()
{
	int G;
	node *temp=NULL;
		if(Root==NULL)
		{
			cout<<"\nBST Is Empty";
			return 0;
		}
		else
		{
			cout<<"\nLevel Order Traversal : ";
	        temp=Root;
	        G=temp->data;
	          Q.enqueue(temp);
	          while(Q.empty()==0)
	          {
	        	  temp=Q.dequeue();

	        	  if(G<temp->data)
	        		  G=temp->data;
	        	  if(temp->Lchild!=NULL)
	        		  Q.enqueue(temp->Lchild);
	        	  if(temp->Rchild!=NULL)
	        		  Q.enqueue(temp->Rchild);
	          }
	          return G;
		}

	return G;
}
int main() {

	BST bst;
	int key,de;
	node *d;
	int c;
	while(c<12)
	{
		cout<<"\n\n1.Create BST \n2.Search (Recursive) \n3.Search (Non_Recursive) \n4.Level Order Traversal";
		cout<<"\n5.Recursive Traversal \n6.Non_Recursive Traversal";
		cout<<"\n7.Height of BST(Non_Recursive)\n8.Mirror BST (Recursive) \n9.Mirror BST (Iterative) \n10.Max Element of BST";
	    cout<<"\n11.Delete \n12.Exit";
		cout<<"\nEnter Your Choice :";
	    cin>>c;
	    switch(c)
	    {
	    case 1:
	    	bst.create();
	    	break;
	    case 2:
	    	cout<<"\nEnter Element to search :";
	    		cin>>key;
	    		bst.Rec_search(bst.Root,key);
	    	break;
	    case 3:
	    	cout<<"\nEnter Element to search :";
	    		cin>>key;
	    		bst.Non_Rec_search(key);
	    	break;
	    case 4:
	    	bst.Tra_Levelorder();
	    	break;
	    case 5:
                 bst.Recu_Tra();
                 break;
	    case 6:
	    	  bst.Non_Recu_Tra();
	    	break;
	    case 7:
	    	cout<<"\nHeight of BST: "<<bst.Non_Rec_Height();
	    	break;
	    case 8:
	    	cout<<"\nBefor Mirroring BST Level Order Traversing";
	    	bst.Tra_Levelorder();
	    	bst.Rec_Mirror(bst.Root);
	    	cout<<"\nMirroring DONE Recursively....";
	    	cout<<"\nAfter Mirroring BST Level Order Traversal";
	    	bst.Tra_Levelorder();
	    	break;
	    case 9:
	    	cout<<"\nBefor Mirroring BST Level Order Traversing";
	    		    	bst.Tra_Levelorder();
	    	           bst.Itra_Mirror();
	    	cout<<"\nAfter Mirroring BST Level Order Traverse";
	    		    	bst.Tra_Levelorder();
	    	break;
	    case 10:
	    	cout<<"\nThe LARGEST Element of BST is : "<<bst.MaxEle();
	    	break;
	    case 11:
	    	cout<<"\nEnter Element for Delete :";
	    	cin>>de;
	    	    d=bst.Delete(de,bst.Root);
	    	   cout<<"\nElement deleted : "<<d->data;
	    	break;
	    case 12:
	    	return 0;
	    	break;
	    }
	}

	return 0;
}
