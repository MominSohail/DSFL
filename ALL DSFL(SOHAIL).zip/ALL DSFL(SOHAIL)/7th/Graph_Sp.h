/*
 * Prims.h
 *
 *  Created on: 08-Mar-2016
 *      Author: pict
 */

#ifndef GRAPH_SP_H_
#define GRAPH_SP_H_
#include<string.h>

struct edge
{
	int Start,End,Weight;
};

class Graph_SPT
{
public:
	int graph_Ad_mat[20][20];//matrix for prim's


	edge Sp_Table[30],Sp_Tree[30];
	  int Sp_Ver=0,Sp_TV=0;
	  int edges,Ver;
	  int parent[30];
	  void sort();
	  int find(int ver);
	  void Union(int v1,int v2);

	  char V_name[];
	void inputGraph();
	void Display_Mat();
	void mini_prim();
	void mini_Kruskal();
	int check(char S[10]);
};

#endif /* GRAPH_SP_H_ */
